import java.util.ArrayList;
import java.util.List;
class Car extends Thread
{
    String id;
    ChargingStation chargingstation;
    public Car(String id,ChargingStation chargingstation)
    {
        this.id=id;
        this.chargingstation=chargingstation;
    }
    public void run()
    {
        try {
            chargingstation.add(this, id);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
class ChargingStation //implements Runnable
{
    Car c;
    String id;
    List<Car> waitingList = new ArrayList<>();
    synchronized void add(Car c, String id) throws InterruptedException
    {
        this.id=id;
        this.c=c;
        waitingList.add(c);
        System.out.println(c.id+" added to list.");
        System.out.println(c.id+" going to sleep for 2 sec");
        System.out.println(c.id+"calling time checker");
        timechecker();
        System.out.println("testing...");
        Thread.sleep(1000);
        if(waitingList.contains(c))
        {
            System.out.println(c.id+ "is awake and removing inside addddddd....");
            waitingList.remove(c);
            System.out.println(id+" removed inside adddddd....");
        }
        else{
            System.out.println("just "+id+" left");
        }
    }
    void timechecker() throws InterruptedException
    {
         TC tc=new TC(c,this);
         tc.start();
         //tc.join();   
    }
}
class TC extends Thread
{
    ChargingStation chargingstation;
    Car c;
    public TC(Car c,ChargingStation chargingstation)
    {
        this.chargingstation=chargingstation;
        this.c=c;
    }
    public synchronized void run()
    {
        for(int i=1;i<=3;i++)
        {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println(i+" Second over for "+c.id);
        }
        if(chargingstation.waitingList.contains(c))
        {
            System.out.println(c.id+" removing inside time checker....");
            chargingstation.waitingList.remove(c);
            System.out.println(c.id+" removed inside time checker....");
            System.out.println("gonna stop "+c.id+" thread.");
            Thread.interrupted();
        }
        else{
            Thread.interrupted();
            System.out.println("stopped "+c.id+" thread.");
        }
    }
}

public class Main
{
    public static void main(String[] args) throws InterruptedException {

        ChargingStation s=new ChargingStation();
        Car one=new Car("car1",s); 
        Car tc=new Car("car2",s);
        Car three=new Car("car3",s);

        one.start();
        tc.start();
        three.start(); 

        one.join();
        tc.join();
        three.join();

        Thread.sleep(10000);
        System.out.println(s.waitingList);
    }
}